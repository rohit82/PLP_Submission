package com.cg.empSystem.service;

import java.util.List;

import com.cg.empSystem.dto.Department;
import com.cg.empSystem.dto.Employee;
import com.cg.empSystem.dto.Grade;
import com.cg.empSystem.dto.UserMaster;
import com.cg.empSystem.exception.EmployeeException;

public interface EmployeeService {
	//Common
		List<String> getDeptname() throws EmployeeException;
		int isValid(String userName, String userPassword) throws EmployeeException;
		public Employee searchId(String Id) throws EmployeeException;
		
		//Admin Functionality
		
		UserMaster addUser(Employee emp) throws EmployeeException;
		
		UserMaster getUserDetails(String userId) throws EmployeeException;
		
		boolean updateEmp(Employee emp) throws EmployeeException;
		Department getDeptName(int deptId ) throws EmployeeException;

		//Employee
		List<Employee> showAllEmployee() throws EmployeeException;
		List<Employee> searchEmployeeOnFirstName(String firstName) throws EmployeeException;
		List<Employee> searchEmployeeOnLastName(String lastName) throws EmployeeException;
		List<Employee> searchEmployeeOnMaritalStatus(String maritalStatus) throws EmployeeException;
		
		List<Employee> SearchGrade(String grade) throws EmployeeException;
		public List<Grade> getData(String grade) throws EmployeeException;
		
		List<Employee> searchEmployeeOnDeptName(String deptName) throws EmployeeException;
		
	
}
