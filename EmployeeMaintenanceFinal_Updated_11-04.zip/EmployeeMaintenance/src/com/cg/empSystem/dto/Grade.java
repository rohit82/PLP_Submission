package com.cg.empSystem.dto;



import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.ManyToAny;
@Entity(name="grade")
@Table(name="Grade_Master")
@NamedQueries({@NamedQuery(name="getGrade",query="select g from grade g where gradeCode is :grade")


})
public class Grade {

	private String gradeCode;
	private String gradeDescription;
	private int gradeMinSalary;
	private int gradeMaxsalary;
	private List<Employee> empGradeList;
	
	
	@Id
	@Column(name="GRADE_CODE")
	public String getGradeCode() {
		return gradeCode;
	}
   public void setGradeCode(String gradeCode) {
		this.gradeCode = gradeCode;
	}
   @Column(name="DESCRIPTION")
	public String getGradeDescription() {
		return gradeDescription;
	}
	public void setGradeDescription(String gradeDescription) {
		this.gradeDescription = gradeDescription;
	}
	
	@Column(name="MIN_SALARY")
	public int getGradeMinSalary() {
		return gradeMinSalary;
	}
	public void setGradeMinSalary(int gradeMinSalary) {
		this.gradeMinSalary = gradeMinSalary;
	}
	
	@Column(name="MAX_SALARY")
	public int getGradeMaxsalary() {
		return gradeMaxsalary;
	}
	public void setGradeMaxsalary(int gradeMaxsalary) {
		this.gradeMaxsalary = gradeMaxsalary;
	}

	@Override
	public String toString() {
		return "Grade [gradeCode=" + gradeCode + ", gradeDescription="
				+ gradeDescription + ", gradeMinSalary=" + gradeMinSalary
				+ ", gradeMaxsalary=" + gradeMaxsalary + ", empGradeList="
				+ empGradeList + "]";
	}
	
	
	
	
	
	
}
